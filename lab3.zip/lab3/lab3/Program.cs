﻿using System;

namespace lab3
{
    public partial class Airline
    {

        public void Info()
        {
            Console.WriteLine($"\n\t|Пункт назначения: {To},\n\t|Номер рейса: {num},\n\t|Тип самолета = {type},\n\t|Время вылета = {time},\n\t|День недели = {day}\n");
        }

        public override string ToString()
        {
            return ($"\n\t|Пункт назначения: {To},\n\t|Номер рейса: {num},\n\t|Тип самолета = {type},\n\t|Время вылета = {time},\n\t|День недели = {day}\n");
        }

        //public override int GetHashCode()
        //{
        //    // 269 или 47 простые
        //    int hash = 269;
        //    hash = string.IsNullOrEmpty(To) ? 0 : To.GetHashCode();
        //    hash = (hash * 47) + num.GetHashCode();
        //    return hash;
        //}

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        public override bool Equals(object obj)
        {
            if (obj == null) return false;
            if (obj.GetType() != this.GetType()) return false;
            Airline airl = (Airline)obj;
            return (this.To == airl.To && this.num == airl.num && this.type == airl.type && this.time == airl.time && this.day == airl.day);
        }

        public static void list_of_Tos(Airline[] arr, ref string Tos)
        {
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i].To.Equals(Tos))
                {
                    Console.WriteLine($"\n\t|Пункт назначения: {arr[i].To},\n\t|Номер рейса: {arr[i].num},\n\t|Тип самолета = {arr[i].type},\n\t|Время вылета = {arr[i].time},\n\t|День недели = {arr[i].day}\n");
                }
            }
        }
        public static void list_of_Days(Airline[] arr, string dd)
        {
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i].day.Equals(dd))
                {
                    Console.WriteLine($"\n\t|Пункт назначения: {arr[i].To},\n\t|Номер рейса: {arr[i].num},\n\t|Тип самолета = {arr[i].type},\n\t|Время вылета = {arr[i].time},\n\t|День недели = {arr[i].day}\n");
                }
            }
        }

    }

    //Пункт назначения, Номер рейса, Тип самолета, Время вылета, Дни недели.

    public partial class Airline
    {
        const string HEHEHE = "Бесполезная константа для задания";
        public static int Nums = 0;
        public readonly int id; //Поле доступное только для чтения
        string To { get; set; }
        int num { get; } = 0;
        string type { get; set; }
        string time { get; set; }
        string day { get; set; }

        public Airline()
        {
            this.id = Airline.Nums++;
            this.To = "-";
            this.num = 0;
            this.type = "-";
            this.time = "-";
            this.day = "-";
        }
        private Airline(int a,int b)
        {
            int s = a + b;
        }
        static Airline()
        {
            var OO = new Airline(5, 4);
        }

        public Airline(string To, int num, string type, string time, string day):this()
        {
            this.id = Airline.Nums++;
            this.To = To;
            this.num = num;
            this.type = type;
            this.time = time;
            this.day = day;
        }

    }

    class Program
    {
        static void Main(string[] args)
        {

            Airline F1 = new Airline("Minsk", 01, "pass", "12:10", "Mon");
            Airline F2 = new Airline("Moskow", 02, "pass","20:50","Tue");
            Airline F3 = new Airline();
            var F4 = new Airline("Ivanovo", 10, "pass", "00:50", "Fri");

            Console.WriteLine("Все рейсы:");
            F1.Info();
            F2.Info();
            F3.Info(); 
            F4.Info();

            Airline[] ALs = new Airline[4] { new Airline("Minsk", 01, "pass", "12:10", "Mon"),
                                             new Airline("Moskow", 02, "pass","20:50","Tue"),
                                             new Airline("Moskow", 03, "pass","21:50","Mon"),
                                             new Airline("Moskow", 04, "pass","11:20","Tue")};

            Console.Write("\nРавенство двух рейсов: ");
            if (F1.Equals(F2)) Console.WriteLine("Равны");
            else Console.WriteLine("Не равны");
            Console.WriteLine("\nЧисло созданных обьектов: " + Airline.Nums);
            Console.WriteLine("\nОпределение типа: " + F1.GetType());
            Console.WriteLine("\nХэш-код объекта: " + F1.GetHashCode());
            Console.WriteLine("\nИнформация объекта:\n" + F1.ToString());

            string nAL = "Minsk";
            Console.WriteLine($"\tCписок рейсов для заданного пункта назначения ({nAL}):");
            Airline.list_of_Tos(ALs, ref nAL);

            string dd = "Tue";
            Console.WriteLine($"\tCписок рейсов для заданного дня недели ({dd}):");
            Airline.list_of_Days(ALs, dd);
        }
    }

}
