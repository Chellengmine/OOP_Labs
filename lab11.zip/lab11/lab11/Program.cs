﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;

namespace lab11
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] month = { "Январь", "Февраль", "Март", "Апрель", "Май", "Июнь", "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь" };

            var lengthMonth = from key in month
                              where key.Length == 6
                              orderby key
                              select key;

            var winterOrSummerMonth = from w in month
                                      where w == "Июнь" || w == "Июль" || w == "Август"
                               || w == "Декабрь" || w == "Январь" || w == "Февраль"
                                      orderby w
                                      select w;

            var ascendingMonth = from a in month
                                 orderby a ascending
                                 select a;

            var absMonth = from abs in month
                           where abs.Contains("а") && abs.Length >= 4
                           orderby abs
                           select abs;


            foreach (var i in lengthMonth)
            {
                Console.WriteLine(i);
            }
            Console.WriteLine();
            foreach (var i in winterOrSummerMonth)
            {
                Console.WriteLine(i);
            }
            Console.WriteLine();
            foreach (var i in ascendingMonth)
            {
                Console.WriteLine(i);
            }
            Console.WriteLine();
            foreach (var i in absMonth)
            {
                Console.WriteLine(i);
            }

            Console.WriteLine("\n\n -\t-\t-\t-\t-\t-\t-\t-\n");

            List<Airline> airlines = new List<Airline>
            {
                new Airline {To = "Москва", Time=10.45, Day = "Понедельник"},
                new Airline {To = "Минск", Time=11.45, Day = "Пятница"},
                new Airline {To = "Санкт-Петербург", Time=12.45, Day = "Среда"},
                new Airline {To = "Иваново", Time=14.45, Day = "Вторник"},
                new Airline {To = "Минск", Time=15.45, Day = "Суббота"}
            };

            //Cписок рейсов для заданного пункта назначения;
            var findTo = from airline in airlines
                         where airline.To == "Минск"
                         select airline;

            Console.WriteLine();
            foreach (Airline airline in findTo)
                Console.WriteLine($"{airline.To} {airline.Day} {airline.Time}");
            Console.WriteLine();


            //Rоличество рейсов для заданного дня недели
            var findDay = from airline in airlines
                          where airline.Day == "Понедельник"
                          select airline;

            foreach (Airline airline in findDay)
                Console.WriteLine($"{airline.To} {airline.Day} {airline.Time}");
            Console.WriteLine();

            //Рейс который вылетает в понедельник раньше всех
            var findEarly = airlines.Where(airline => (airline.Day == "Понедельник")).OrderBy(airline => airline.Time).Take(1);

            foreach (Airline airline in findEarly)
                Console.WriteLine($"{airline.To} {airline.Day} {airline.Time}");
            Console.WriteLine();

            //Рейс который вылетает в среду или пятницу позже всех
            var findLate = airlines.Where(airline => (airline.Day == "Пятница")|| (airline.Day == "Среда")).OrderByDescending(airline => airline.Time).Take(1);

            foreach (Airline airline in findLate)
                Console.WriteLine($"{airline.To} {airline.Day} {airline.Time}");
            Console.WriteLine();

            //Список рейсов, упорядоченных по времени вылета
            var sortedTime = from airline in airlines
                             orderby airline.Time ascending
                             select airline;

            foreach (Airline airline in sortedTime)
                Console.WriteLine($"{airline.To} {airline.Day} {airline.Time}");
            Console.WriteLine();

            Console.WriteLine("\n\n -\t-\t-\t-\t-\t-\t-\t-\n");

            List<Character> characters = new List<Character>()
               {
                 new Character { Name = "Ху Тао", Elem ="Пиро" },
                 new Character { Name = "Мона", Elem ="Гидро" },
                 new Character { Name = "Кли", Elem ="Пиро" },
                 new Character { Name = "Райдэн", Elem ="Электро" },
                 new Character { Name = "Сахароза", Elem ="Анемо" },
                 new Character { Name = "Беннет", Elem ="Пиро" },
                 new Character { Name = "Син Цю", Elem ="Гидро" },
                 new Character { Name = "Диона", Elem ="Крио" },
            };
            List<Grade> grades = new List<Grade>()
            {
                 new Grade {Name="Ху Тао", Stars="5*"},
                 new Grade {Name="Мона", Stars="5*"},
                 new Grade {Name="Кли", Stars="5*"},
                 new Grade {Name="Райдэн", Stars="5*"},
                 new Grade { Name = "Сахароза", Stars ="4*" },
                 new Grade { Name = "Беннет", Stars ="4*" },
                 new Grade { Name = "Син Цю", Stars ="4*" },
                 new Grade { Name = "Диона", Stars ="4*" },
            };

            var result = from ch in characters
                         join gr in grades on ch.Name equals gr.Name
                         select new { Name = gr.Name, Stars = gr.Stars, Elem = ch.Elem };

            foreach (var item in result)
                Console.WriteLine($"{item.Name} - {item.Stars} ({item.Elem})");
            Console.Read();
        }
        public class Character
        {
            public string Name { get; set; }
            public string Elem { get; set; }
        }
        public class Grade
        {
            public string Name { get; set; }
            public string Stars { get; set; }
        }
        class Airline
        {
            public string To { get; set; }
            public double Time { get; set; }
            public string Day { get; set; }
        }
    }
}

