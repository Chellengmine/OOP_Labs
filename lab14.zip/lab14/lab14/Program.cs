﻿using System;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization.Formatters.Soap;
using System.Xml.Serialization;
using System.Runtime.Serialization.Json;
using System.IO;
using System.Collections.Generic;
using System.Xml;
using System.Xml.Linq;

namespace LabRab14
{
    public class Program
    {
        static void Main(string[] args)
        {
            Airline airline = new Airline() { number = 10 };
            BinaryFormatter formatter = new BinaryFormatter();
            using (FileStream fs = new FileStream("airline.dat", FileMode.OpenOrCreate))
            {
                formatter.Serialize(fs, airline);

                Console.WriteLine(" | Объект сериализован");
            }
            using (FileStream fs = new FileStream("airline.dat", FileMode.OpenOrCreate))
            {
                Airline newAirline = (Airline)formatter.Deserialize(fs);

                Console.WriteLine(" | Объект десериализован");
                Console.WriteLine(newAirline.number);
            }
            SoapFormatter c = new SoapFormatter();
            using (FileStream fs = new FileStream("airline.soap", FileMode.OpenOrCreate))
            {
                c.Serialize(fs, airline);

                Console.WriteLine(" | Объект сериализован");
            }
            using (FileStream fs = new FileStream("airline.soap", FileMode.OpenOrCreate))
            {
                Airline newAirline = (Airline)c.Deserialize(fs);

                Console.WriteLine(" | Объект десериализован");
                Console.WriteLine(newAirline.number);
            }
            XmlSerializer xml = new XmlSerializer(typeof(Airline));
            using (FileStream fs = new FileStream("airline.xml", FileMode.OpenOrCreate))
            {
                xml.Serialize(fs, airline);
                Console.WriteLine(" | Объект сериализован");
            }
            using (FileStream fs = new FileStream("airline.xml", FileMode.OpenOrCreate))
            {
                Airline newAirline = (Airline)xml.Deserialize(fs);

                Console.WriteLine(" | Объект десериализован");
                Console.WriteLine(newAirline.number);
            }

            DataContractJsonSerializer jsonFormatter = new DataContractJsonSerializer(typeof(Airline));

            using (FileStream fs = new FileStream("Airline.json", FileMode.OpenOrCreate))
            {
                jsonFormatter.WriteObject(fs, airline);
                Console.WriteLine(" | Объект сериализован");
            }

            using (FileStream fs = new FileStream("Airline.json", FileMode.OpenOrCreate))
            {
                Airline newAirline = (Airline)jsonFormatter.ReadObject(fs);
                Console.WriteLine(" | Объект десериализован");
                Console.WriteLine(newAirline.number);
            }
            XmlSerializer xmlList = new XmlSerializer(typeof(List<Airline>));
            List<Airline> airlines = new List<Airline>(3);
            airlines.Add(new Airline { number = 20 });
            airlines.Add(new Airline { number = 30 });
            airlines.Add(new Airline { number = 40 });
            using (FileStream fs = new FileStream("airlines.xml", FileMode.OpenOrCreate))
            {

                xmlList.Serialize(fs, airlines);


                Console.WriteLine(" | Объект сериализован");
            }

            Console.WriteLine();
            XmlDocument xDoc = new XmlDocument();
            xDoc.Load("airline.xml");
            XmlElement xRoot = xDoc.DocumentElement;


            XmlNodeList childnodes = xRoot.SelectNodes("*");
            foreach (XmlNode n in childnodes)
                Console.WriteLine(n.OuterXml);

            Console.WriteLine();

            XmlNodeList childnodes_ = xRoot.SelectNodes("//Airline/number");
            foreach (XmlNode n in childnodes_)
                Console.WriteLine(n.InnerText);


            XDocument xdoc = new XDocument(new XElement("Airlines",
                new XElement("airline", new XAttribute("name", "Moscow"),
                new XElement("company", "Belavia"), new XElement("price", "15000")),

                new XElement("airline", new XAttribute("name", "Canada"),
                new XElement("company", "Utair"), new XElement("price", "30000"))));

            xdoc.Save("Airlines.xml");
            XDocument xmldoc = XDocument.Load("Airlines.xml");

            Console.WriteLine(" || Первый Linq to Xml запрос:");
            foreach (XElement phoneElement in xmldoc.Element("Airlines").Elements("airline"))
            {
                XAttribute nameAttribute = phoneElement.Attribute("name");
                XElement companyElement = phoneElement.Element("company");
                XElement priceElement = phoneElement.Element("price");
                if (nameAttribute != null && companyElement != null && priceElement != null)
                {
                    Console.WriteLine(" | Airline: {0}", nameAttribute.Value);
                    Console.WriteLine(" | Company: {0}", companyElement.Value);
                    Console.WriteLine(" | Price: {0}", priceElement.Value);
                }
                Console.WriteLine();
            }
            Console.WriteLine("\n || Второй Linq to Xml запрос:");
            foreach (XElement phoneElement in xmldoc.Element("Airlines").Elements("airline"))
            {
                XAttribute nameAttribute = phoneElement.Attribute("name");
                XElement companyElement = phoneElement.Element("company");
                XElement priceElement = phoneElement.Element("price");
                if (nameAttribute != null && companyElement != null && priceElement.Value == "30000")
                {
                    Console.WriteLine(" | Airline: {0}", nameAttribute.Value);
                    Console.WriteLine(" | Company: {0}", companyElement.Value);
                    Console.WriteLine(" | Price: {0}", priceElement.Value);
                }
                Console.Read();
            }
        }
        public interface IAirlineControl
        {
            int time { get; set; }
            int braking_distances { get; set; }

        }
        [Serializable]
        public class Airline : IAirlineControl
        {
            public int number { get; set; }
            public string classification_group { get; set; }
            public int time { get; set; }
            public int braking_distances { get; set; }
            public override string ToString()
            {
                return "IAirlineControl.Airline";

            }
        }
    }
}

