﻿using System;

namespace lab5
{

    //GeometricShape, Circle, Rectangle, IControl (interface with show, input, resize, etc.), Control, Checktbox, Radiobutton, Button
    class Program
    {
        static void Main(string[] args)
        {
            ControlElem B1 = new Checktbox();
            ControlElem B2 = new Radiobutton();
            ControlElem B3 = new Button();
            Console.WriteLine(B1.Show());
            Console.WriteLine(B2.Show());
            Console.WriteLine(B3.Show());

            Console.WriteLine(B3.Resize());
            //Console.WriteLine(ControlElem.Nums);

            Console.WriteLine(B3.Input("status","on"));
            Console.WriteLine(B3.Show());

            Console.WriteLine();

            Console.WriteLine($"B2 is Checktbox: {B2 is Checktbox}");
            Console.WriteLine($"B2 is ControlElem: {B2 is ControlElem}");
            IControl pC1 = B2 as IControl;
            if (pC1 != null) Console.WriteLine(pC1);
            else Console.WriteLine("B2 as IControl : Успешное преобразование типов");
            Checktbox pC2 = B2 as Checktbox;
            if (pC2 != null) Console.WriteLine(pC2);
            else Console.WriteLine("B2 as Checktbox : Успешное преобразование типов");

            Console.WriteLine();

            Circle D1 = new Circle(15);
            Rectangle D2 = new Rectangle(25);

            Console.WriteLine(D1.ToString());
            Console.WriteLine(D2.ToString());

            Console.WriteLine();

            ControlElem A1 = new Checktbox();
            ControlElem A2 = new Radiobutton();
            ControlElem A3 = new Button();
            dynamic[] PrinterArray = { A1,A2,A3 };

            Console.WriteLine("Printer");
            Console.WriteLine(Printer.IAmPrinting(A1));
            Console.WriteLine(Printer.IAmPrinting(A2));
            Console.WriteLine(Printer.IAmPrinting(A3));
        }
    }
}