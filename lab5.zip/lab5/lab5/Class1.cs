﻿using System;
using System.Linq;

namespace lab5
{
    class GeometricShape
    {
        public int square { get; set; }
        public virtual string ToString()
        {
            return "lab5.GeometricShape";
        }
    }
    sealed class Circle : GeometricShape

    {
        public string name = "Круг";
        public int square { get; set; }
        public Circle(int square)
        {
            this.square = square;
        }
        public override string ToString()
        {
            return ($"Геометрическая фигура - {this.name}, ёё площадь: {this.square}");
        }

    }

    sealed class Rectangle : GeometricShape
    {
        public string name = "Квадрат";
        public int square { get; set; }
        public Rectangle(int square)
        {
            this.square = square;
        }

        public override string ToString()
        {
            return ($"Геометрическая фигура - {this.name}, ёё площадь: {this.square}");
        }
    }
    abstract class ControlElem
    {
        public static int Nums = 0;
        public string type { get; set; }
        public int size { get; set; }
        public bool status { get; set; }


        public ControlElem()
        {
            this.type = type;
            this.status = status;
            this.size = ControlElem.Nums++;
        }
        public string Show()
        {
            return ($"|| || Элемент управления - {type}, состояние - {status}");
        }
        public virtual string ToString()
        {
            return "ControlElem.Checktbox";
        }
        public int Resize()
        {
            Console.Write("Элемент №");
            return ++size;
        }
        public string Input(string obj,string param)
        {
            if (obj == "status") { if (param == "on") this.status = true; if (param == "off") this.status = false; }
            return $"Добавлен {obj}";
        }


    }
    class Checktbox : ControlElem
    {
        public Checktbox() : base()
        {
            type = "Checktbox";
            status = false;
        }
        public override string ToString()
        {
            return $"ControlElem.{type}";
        }

    }
    class Radiobutton : ControlElem
    {
        public Radiobutton() : base()
        {
            type = "Radiobutton";
            status = false;
        }
        public override string ToString()
        {
            return $"ControlElem.{type}";
        }
    }
    class Button : ControlElem
    {
        public Button() : base()
        {
            type = "Button";
            status = false;
        }
        public override string ToString()
        {
            return $"ControlElem.{type}";
        }
    }
    static class Printer
    {
        static internal string IAmPrinting(object someobj)
        {
            if (someobj is ControlElem)
            {
                if (someobj is Checktbox)
                {
                    ControlElem chbox = someobj as Checktbox;
                    return chbox.ToString();
                }
                if (someobj is Radiobutton)
                {
                    ControlElem rb = someobj as Radiobutton;
                    return rb.ToString();
                }
                if (someobj is Button)
                {
                    ControlElem chb = someobj as Button;
                    return chb.ToString();
                }
                ControlElem el = someobj as ControlElem;
                return Convert.ToString(el);
            }
            return "Неизвестная ошибка";
        }
    }
}