﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;

namespace lab10
{
    class Program
    {
        static void Main(string[] args)
        {
            MyCollection books = new MyCollection();
            books.Add(new Book(1,"Волонтеры вечности"));
            books.Add(new Book(2,"Чужак"));
            books.Add(new Book(3,"Простые волшебные вещи"));
            books.Show();
            books.Remove(new Book(1,"Волонтеры вечности"));
            books.Show();

            Console.WriteLine();
            //////////////////////////////////////////

            MyList<int> list = new MyList<int>();
            for (int i = 1; i <= 10; i++)
            {
                list.Add(i);
            }
            list.Show();

            for (int i = 3; i <= 6; i++)
            {
                list.Remove(i);
            }
            list.Show();

            list.Add(10);
            list.Insert(0,20);
            list.Show();

            Stack<int> stack = new Stack<int>();
            Console.Write(" || Stack: ");
            foreach (int i in list)
            {
                stack.Push(i);
                Console.Write(stack.Peek() + " ");
            }

            Console.WriteLine();
            //////////////////////////////////////////

            ObservableCollection<Book> obs = new ObservableCollection<Book>();
            obs.CollectionChanged += Notify;
            Book im1 = new Book(1,"Волонтеры вечности");
            Book im2 = new Book(2,"Чужак");
            Book im3 = new Book(3,"Простые волшебные вещи");
            Console.WriteLine();
            obs.Add(im1);
            obs.Add(im2);
            obs.Add(im3);
            obs.Remove(im1);
            Console.WriteLine();

            Console.Write(" || Observable collection:   ");
            foreach (Book i in obs)
            {
                Console.Write(i.Name+ "   ");
            }
            Console.WriteLine();

        }

        private static void Notify(object sender, NotifyCollectionChangedEventArgs e)
        {
            if (e.Action == NotifyCollectionChangedAction.Add)
            {
                Console.WriteLine(" || Add comlete");
            }
            else if (e.Action == NotifyCollectionChangedAction.Remove)
            {
                Console.WriteLine(" || Remove complete");
            }
        }
    }
}
