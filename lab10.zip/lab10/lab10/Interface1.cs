﻿using System;
using System.Collections.Generic;
using System.Text;

namespace lab10
{
    interface IDictionary<TKey, TValue>
    {
    }
}
