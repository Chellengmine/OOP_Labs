﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.IO.Compression;

namespace lab13
{
    class Program
    {
        static void Main(string[] args)
        {

            AEVLog.WriteLog(AEVDiskInfo.FreePlaceDiskInfo());
            AEVLog.WriteLog(AEVFileInfo.MethodFileInfo());
            AEVLog.WriteLog(AEVDirInfo.AEVDirInfoMethod());
            AEVFileManager.FileAndDirectoryWorkMethod();
            AEVFileManager.FileAndDirectoryWorkMethodTwo();
            AEVFileManager.Compress();
            AEVFileManager.Decompress();
            //ViewAEVLogFile.ViewAEVLogFileMethod();
            //AEVLog.ReadLog(); //Читает файл
            Console.Read();
        }
        static class AEVLog
        {
            static string address = @"D:\study\2 курс\ООП\ЛР 13\lab13\AEVlogfile.txt";
            public static void WriteLog(string text)
            {
                try
                {

                    FileInfo fileInfo = new FileInfo(address);
                    fileInfo.Refresh();

                    var name = fileInfo.Name;
                    var fullName = fileInfo.FullName;
                    var creationTime = fileInfo.CreationTime;
                    var lastAccessTime = fileInfo.LastAccessTime;
                    if (!System.IO.File.Exists("AEVlogfile.txt"))
                    {
                        using (StreamWriter sw = new StreamWriter(address, false, Encoding.UTF8))
                        {
                            sw.WriteLine($"Имя файла: {name}");
                            sw.WriteLine($"Полный путь: {fullName}");
                            sw.WriteLine($"Дата и время создания файла: {creationTime}");
                            sw.WriteLine($"Дата и время последнего изменения файла пользователем: {lastAccessTime}");
                            sw.WriteLine("*****************************************************************************");
                            sw.Write(text);
                            sw.Write("\n\n");
                            sw.Close();
                        }
                    }
                    else
                    {
                        using (StreamWriter sw = new StreamWriter(address, true, System.Text.Encoding.UTF8))
                        {
                            sw.WriteLine($"Имя файла: {name}");
                            sw.WriteLine($"Полный путь: {fullName}");
                            sw.WriteLine($"Дата и время создания файла: {creationTime}");
                            sw.WriteLine($"Дата и время последнего изменения файла пользователем: {lastAccessTime}");
                            sw.WriteLine("*****************************************************************************");
                            sw.Write(text);
                            sw.Write("\n\n");
                            sw.Close();
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
            public static void ReadLog()
            {
                try
                {
                    using (StreamReader sr = new StreamReader(address, System.Text.Encoding.UTF8))
                    {
                        string line;
                        while ((line = sr.ReadLine()) != null)
                        {
                            Console.WriteLine(line);
                        }
                    }

                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }
        public static class AEVDiskInfo
        {
            public static string FreePlaceDiskInfo()
            {
                string text = "";
                DriveInfo[] drives = DriveInfo.GetDrives();
                try
                {
                    foreach (var drive in drives)
                    {
                        Console.WriteLine($"\n" +
                            $"Объем доступного места на диске:\n{drive.Name} {drive.AvailableFreeSpace} байт");
                        Console.WriteLine($"Файловая система: {drive.DriveFormat}");
                        Console.WriteLine($"Общий доступный объем места на диске: {drive.TotalFreeSpace} байт");
                        Console.WriteLine($"Метка тома: {drive.VolumeLabel}");
                        Console.WriteLine($"Oбщий размер диска в байтах: {drive.TotalSize} байт");
                        text += $"\nОбъем доступного места на диске:\n{drive.Name} {drive.AvailableFreeSpace} байт\n" +
                            $"Файловая система: {drive.DriveFormat}\n" +
                            $"Общий доступный объем места на диске: {drive.TotalFreeSpace} байт\n" +
                            $"Метка тома: {drive.VolumeLabel}\n" +
                            $"Oбщий размер диска в байтах: {drive.TotalSize} байт\n";
                    }

                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                return text;

            }
        }
        public static class AEVFileInfo
        {
            public static string MethodFileInfo()
            {
                FileInfo fileInfo = new FileInfo(@"D:\study\2 курс\ООП\ЛР 13\lab13\AEVlogfile.txt");
                Console.WriteLine($"\nИмя файла: {fileInfo.Name}");
                Console.WriteLine($"Полный путь: {fileInfo.DirectoryName}");
                Console.WriteLine($"Размер файла: {fileInfo.Length} байт");
                Console.WriteLine($"Расширение файла: {fileInfo.Extension}");
                Console.WriteLine($"Дата и время создания файла: {fileInfo.CreationTime}");

                return $"\nИмя файла: {fileInfo.Name}\n" +
                    $"Полный путь: {fileInfo.DirectoryName}\n" +
                    $"Размер файла: {fileInfo.Length}\n байт" +
                    $"Расширение файла: {fileInfo.Extension}\n" +
                    $"Дата и время создания файла: {fileInfo.CreationTime}\n";
            }
        }
        public static class AEVDirInfo
        {
            public static string AEVDirInfoMethod()
            {
                string text = "";
                string[] files = Directory.GetFiles("D:\\");
                Console.WriteLine($"\n" +
                    $"Количество файлов: {files.Length}");
                text += $"\nКоличество файлов: {files.Length}";
                var time = Directory.GetCreationTime("D:\\");
                Console.WriteLine($"Дата создания каталога D: {time}");
                text += $"\nДата создания каталога D: {time}";
                string[] dirs = Directory.GetDirectories("D:\\");
                Console.WriteLine($"Количество подкаталогов каталога  D = {dirs.Length}");
                text += $"\nКоличество подкаталогов каталога  D = {dirs.Length}";
                var parent = Directory.GetParent("D:\\");
                Console.WriteLine($"Родительский каталог каталога D: {parent}");
                text += $"\nРодительский каталог каталога D: {parent}";
                return text;
            }
        }
        public static class AEVFileManager
        {
            public static void FileAndDirectoryWorkMethod()
            {
                string[] listFiles = Directory.GetFiles("C:\\");
                string[] listDirectories = Directory.GetDirectories("C:\\");
                string path = @"D:\study\2 курс\ООП\ЛР 13\lab13\AEVInspect";
                string address = @"D:\study\2 курс\ООП\ЛР 13\lab13\AEVInspect\bvodirinfo.txt";
                DirectoryInfo dirInfo = new DirectoryInfo(path);
                if (!dirInfo.Exists)
                {
                    dirInfo.Create();
                    Console.WriteLine("Директорий создан");
                }
                try
                {
                    using (StreamWriter sw = new StreamWriter(address, false, Encoding.Default))
                    {
                        sw.WriteLine("Some information");
                        sw.Close();
                    }
                }
                catch
                {

                }
                string newPath = @"D:\study\2 курс\ООП\ЛР 13\lab13\info.txt";
                FileInfo fileInf = new FileInfo(address);
                if (fileInf.Exists)
                {
                    fileInf.CopyTo(newPath, true);
                    fileInf.Delete();
                }

            }
            public static void FileAndDirectoryWorkMethodTwo()
            {
                string path = @"D:\study\2 курс\ООП\ЛР 13\lab13\AEVFiles";
                string address = @"D:\study\2 курс\ООП\ЛР 13\lab13\AEVInspect\AEVFiles";
                DirectoryInfo dirInfo = new DirectoryInfo(path);
                if (!dirInfo.Exists)
                {
                    dirInfo.Create();
                    Console.WriteLine("Директорий создан");
                }
                string[] files = Directory.GetFiles(@"D:\study\2 курс\ООП\ЛР 13\lab13\", "*.txt");

                foreach (var s in files)
                {
                    FileInfo info = new FileInfo(s);

                    if (info.Exists)
                    {
                        info.CopyTo(@"D:\study\2 курс\ООП\ЛР 13\lab13\AEVFiles\" + info.Name, true);
                    }
                }
                DirectoryInfo del = new DirectoryInfo(address);
                del.Create();
                del.Delete();

                dirInfo.MoveTo(address);
            }
            internal static void Compress()
            {
                string zipPath = @"D:\study\2 курс\ООП\ЛР 13\lab13\AEVInspect\AEVFiles.zip";
                string address = @"D:\study\2 курс\ООП\ЛР 13\lab13\AEVInspect\AEVFiles";
                ZipFile.CreateFromDirectory(address, zipPath);

            }
            public static void Decompress()
            {
                string zipPath = @"D:\study\2 курс\ООП\ЛР 13\lab13\AEVInspect\AEVFiles.zip";
                string extractPath = @"D:\study\2 курс\ООП\ЛР 13\lab13\AEVFiles";
                ZipFile.ExtractToDirectory(zipPath, extractPath);
            }
        }

    }
    //public static class ViewAEVLogFile
    //{
    //    public static void ViewAEVLogFileMethod()
    //    {
    //        string str = " ";
    //        Console.WriteLine("\nЧтение\n");
    //        FileInfo fileInfo = new FileInfo(@"D:\study\2 курс\ООП\ЛР 13\lab13\AEVlogfile.txt");
    //        using (StreamReader streamReader = new StreamReader(@"D:\study\2 курс\ООП\ЛР 13\lab13\AEVlogfile.txt", Encoding.GetEncoding(1251)))
    //        {
    //            Console.WriteLine();

    //            //  string stroka = streamReader.ReadToEnd();
    //            //  Console.WriteLine(stroka);
    //            int i = 0;
    //            foreach (string s in File.ReadLines(@"D:\study\2 курс\ООП\ЛР 13\lab13\AEVlogfile.txt"))
    //            {
    //                if (s.IndexOf("Дата и время создания файла: 18.12.2019 2") == 0 || i > 0)
    //                {
    //                    str += s + "\n";
    //                    i++;
    //                }

    //            }
    //            Console.WriteLine("В файле {0} записей", i);
    //            Console.WriteLine("Вывод со строки\n");
    //            Console.WriteLine(str);
    //        }
    //        File.Delete(@"D:\study\2 курс\ООП\ЛР 13\lab13\AEVlogfile.txt");
    //        string address = @"D:\study\2 курс\ООП\ЛР 13\lab13\AEVlogfile.txt";
    //        using (StreamWriter streamReader = new StreamWriter(address, true, System.Text.Encoding.UTF8))
    //        {
    //            streamReader.WriteLine(str);
    //        }
    //    }
    //}
}

