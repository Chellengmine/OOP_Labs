﻿using System;
using static lab12.Reflector;

namespace lab12
{
    class Program
    {
        static void Main(string[] args)
        {
            GetAssembly(typeof(String));
            Console.WriteLine("\n -\t-\t-\t-\t-\t-\t-\t-\n");
            Console.WriteLine(" || Вывод конструкторов");
            var Constructorslist = GetConstructors(typeof(String));
            foreach (var value in Constructorslist)
            {
                Console.WriteLine(" | " + value);
            }
            Console.WriteLine("\n\n -\t-\t-\t-\t-\t-\t-\t-\n");
            Console.WriteLine(" || Вывод public методов");
            var Methodslist = GetMethods(typeof(String));
            foreach (var method in Methodslist)
            {
                Console.WriteLine(" | "+method);
            }
            Console.WriteLine("\n\n -\t-\t-\t-\t-\t-\t-\t-\n");
            Console.WriteLine(" || Вывод свойств");
            var Propertieslist = GetProperties(typeof(String));
            foreach (var property in Propertieslist)
            {
                Console.WriteLine(" | " + property);
            }
            Console.WriteLine("\n\n -\t-\t-\t-\t-\t-\t-\t-\n");
            Console.WriteLine(" || Вывод Интерфейсов");
            var interfacelist = GetInterfaces(typeof(String));
            foreach (var face in interfacelist)
            {
                Console.WriteLine(" | " + face);
            }
            Console.WriteLine("\n\n -\t-\t-\t-\t-\t-\t-\t-\n");
            Console.WriteLine(" || Вывод названий методов");
            GetMethodNames(typeof(String));
            Console.WriteLine("\n\n -\t-\t-\t-\t-\t-\t-\t-\n");
        }
    }
}