﻿using System;

namespace lab9
{
    class Program
    {
        static void Main(string[] args)
        {
            User User1 = new User { name = "User1", compress = 150, move = 2 };
            User User2 = new User { name = "User2", compress = 100, move = 1 };
            User User3 = new User { name = "User3", compress = 200, move = 4 };
            User User4 = new User { name = "User4", compress = 125, move = 1 };
            User1.notify += Display;
            User2.notify += Display;
            User3.notify += Display;
            User4.notify += Display;
            User1.Increase();
            User1.Decrease();
            User2.Increase();
            User2.Increase();
            User4.Decrease();
            Console.Read();
        }
        static void Display(string message)
        {
            Console.WriteLine(message);


            //string Str() => message.Replace("U", "?");
            //Func<string> op = Str;
            //message = op();
            //Console.WriteLine(" || Замена символа 'U' на '?'\n" + message);

            //string Delete_symbol() => message.Replace("?", "");
            //op = Delete_symbol;
            //message = op();
            //Console.WriteLine(" || Удаление символа '?'\n"+message);

            //string Probel() => message.Insert(message.Length, "!");
            //op = Probel;
            //message = op();
            //Console.WriteLine(" || Добавление '!' в конец сообщения\n"+message);

            //string Upper() => message.ToUpper();
            //op = Upper;
            //message = op();
            //Console.WriteLine(" || Перевод в верхний регистр\n" +message);
        }
    }
}
