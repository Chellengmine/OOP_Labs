﻿using System;

namespace lab4
{
    public partial class Arr
    {
        public class Owner
        {
            private string _name;
            private string _organization;
            private static int Id;
            public Owner(string name, string organization)
            {
                this._name = name;
                this._organization = organization;
                Id++;
            }
            public void Print()
            {
                Console.WriteLine($"\n || ID: {Id}, Имя: {_name}, Организация: {_organization}");
            }
        }
        public class Date
        {
            private DateTime _time;
            public Date()
            {
                _time = DateTime.Now;
            }
            public void ShowDate()
            {
                Console.WriteLine($" || {_time}");
            }
            private int[] _arr;
        }

        public Owner _Owner { get; set; }
        public Date _Date { get; set; }
        private int[] _arr;
        private int _num;
        public int length;

        public Arr()
        {
            this._arr = new int[0];
            this.length = 0;
        }

        public Arr(int size)
        {
            this._arr = new int[size];
            this.length=length+size;
        }

        public int this[int index]
        {
            get
            {
                int res = int.MinValue;
                try
                {

                    res = this._arr[index];
                }
                catch (IndexOutOfRangeException)
                {
                    Console.WriteLine("Ошибка: в массиве нет {0} элемента!", index);
                }

                return res;
            }
            set
            {
                if (index > -1 && index < this._arr.Length)
                    this._arr[index] = value;
            }
        }
            public int Count
            {
                get { return this._arr.Length; }
            }


        //объединение массивов
        public static Arr operator +(Arr arr1, Arr arr2)
        {
            int size = arr1.Count + arr2.Count;
            Arr res = new Arr(size);

            int g = 0;
            if (g < res.length)
            {
                for (int i = 0; (i < arr1.length); i++)
                {
                    res[g] = arr1[i]; g++;
                }
                for (int j = 0; j < arr1.length; j++)
                {
                    res[g] = arr2[j]; g++;
                }
            }
            return res;
        }

        ///разность со скалярным значением
        public static Arr operator -(Arr obj1, Arr obj2)
            {
            int size = 0;
            if (obj1.length > obj2.length) { size = obj1.length; }
            else { size = obj2.length; }
            Arr obj = new Arr(size);
            int g = 0;
            if (g < obj.length)
            {
                for (int i = 0, j = 0; (i < obj.length); j++, i++)
                {
                    obj[g] = obj1[i] - obj2[j]; g++;
                }
            }
            return obj;
        }

        //проверка на вхождение элемента
        public static bool operator >(Arr arr, int num)
        {
            for (int i = 0; i < arr.length; i++)
            {
                if (num == arr[i])
                {
                    return true;
                }
            }

            return false;
        }
        public static bool operator <(Arr arr, int num)
        {
            for (int i = 0; i < arr.length; i++)
            {
                if (num == arr[i])
                {
                    return false;
                }
            }

            return true;
        }

        //проверка на равенство массивов
        public static bool operator ==(Arr arr1, Arr arr2)
        {
           if (arr1.Count != arr2.Count) { return false; }
           for (int i = 0; (i < arr1.Count); i++)
           {
                if (arr1[i] != arr2[i]) { return false; }
           }
           return true;
        }
        public static bool operator !=(Arr arr1, Arr arr2)
        {
            if (arr1.Count != arr2.Count) { return true; }
            for (int i = 0; (i < arr1.Count); i++)
            {
                if (arr1[i] != arr2[i]) { return true; }
            }
            return false;
        }
        /// Вывод значений элементов массива на экран
        public void Print()
            {
            Console.Write(" || ");
            for (int i = 0; i < _arr.Length; i++)
                    Console.Write("{0} ", _arr[i]);
                Console.WriteLine();
            }
            /// Вывод значений конкретного элементов массива на экран
            public void Print(int index)
            {
                if (index > -1 && index < _arr.Length)
                    Console.WriteLine("{0} элемент со значением {1}", index, _arr[index]);
            }
        }
    }


