﻿using System;

namespace lab4
{ 
    class Program
    {
        static void Main(string[] args)
        {
            Arr.Owner gg = new Arr.Owner("Егор", "ПОИТ-6");
            Arr.Date tt = new Arr.Date();

            Arr arr = new Arr(10);
            Arr arr2 = new Arr(10);
            Random rand = new Random();
            for (int i = 0; i < arr.Count; i++)
                arr[i] = rand.Next(-10, 10);

            for (int i = 0; i < arr2.Count; i++)
                arr2[i] = rand.Next(-10, 10);

            Arr arr5 = arr;

            Console.WriteLine(" | Все массивы: ");
            arr.Print();
            arr2.Print();
            arr5.Print();

            Console.WriteLine($"\n | Равенство массивов: {arr == arr5}");
            Console.WriteLine($"\n | Равенство массивов: {arr == arr2}");

            Console.Write($"\n >> ");
            int k = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine($"\n | Вхождение элемента в массив: {arr>k}");

            Console.WriteLine($"\n | Объединение массивов:");
            Arr arr3 = arr + arr2;
            arr3.Print();
            Console.WriteLine($"\n | Разница массивов:");
            arr3 = arr - arr2;
            arr3.Print();
            
            Console.Write("\n | Сумма элементов:"); StatisticOperations.Sum(arr, arr2).Print();

            Console.Write("\n | Конкантенация элементов:"); StatisticOperations.Concat(arr, arr2).Print();

            Console.WriteLine($" | Разница между максимальным и минимальным: {StatisticOperations.Difference(arr,arr2)}");
            Console.WriteLine($" | Размер массива: {StatisticOperations.GetSize(arr2)}\n");

            Console.WriteLine($" | Удаление гласных из строки: \n || {StatisticOperations.DelVowels("gov513no")}");
            Console.WriteLine($" | Удаление 5 элементов: \n || {StatisticOperations.DelFiveElem("govno564")}");
            Console.WriteLine(" | Удаление 5 элементов:");StatisticOperations.DelFiveElem(arr5).Print();

            gg.Print();
            tt.ShowDate();
        }
    }
}

        
