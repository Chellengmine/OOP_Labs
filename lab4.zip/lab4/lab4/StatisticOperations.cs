﻿using System;

namespace lab4
{
    public static class StatisticOperations
    {
        public static Arr Sum(Arr obj1, Arr obj2)
        {
            Console.WriteLine("\n | Рассматриваемые массивы: ");
            obj1.Print();
            obj2.Print();

            int size = 0;
            if (obj1.length > obj2.length) { size = obj1.length; }
            else { size = obj2.length; }
            Arr obj = new Arr(size);

            int g = 0;
            if (g < obj.length)
            {
                for (int i = 0, j =0; (i < obj.length); j++, i++)
                {
                    obj[g] = obj1[i]+ obj2[j]; g++;
                }
            }
            Console.WriteLine(" | Итоговый массив: ");
            return obj;

        }

        public static Arr Concat(Arr obj1, Arr obj2)
        {
            Console.WriteLine("\n | Рассматриваемые массивы: ");
            obj1.Print();
            obj2.Print();

            int size = obj1.length + obj2.length;
            Arr obj = new Arr(size);

            int g = 0;
            if (g < obj.length)
            {
                for (int i = 0; (i < obj1.length); i++)
                {
                    obj[g] = obj1[i]; g++;
                }
                for (int j = 0; j < obj1.length; j++)
                {
                    obj[g] = obj2[j]; g++;
                }
            }
            Console.WriteLine(" | Итоговый массив: ");
            return obj;
        }

        public static int Difference(Arr arr1, Arr arr2)
        {
            Console.WriteLine("\n | Рассматриваемые массивы: ");
            arr1.Print();
            arr2.Print();

            int min = int.MaxValue;
            int max = int.MinValue;
            int i = 0;

            while(i<arr1.length)
            {
                if (min > arr1[i]) min = arr1[i];
                if (max < arr1[i]) max = arr1[i];
                i++;
            }
            i = 0;
            while (i < arr2.length)
            {
                if (min > arr2[i]) min = arr2[i];
                if (max < arr2[i]) max = arr2[i];
                i++;
            }
           
            Console.WriteLine($" | max = {max}, min = {min}");
            return Math.Abs(max - min);

        }
        public static int GetSize(Arr arr)
        {
            Console.WriteLine();
            int count = 0;
            for(int i = 0; i < arr.length; i++) 
            {
                count++;
            }

            return count;
        }
        //Удаление гласных из строки
        public static string DelVowels(this string str)
        {
            char[] vowels = { 'a', 'e', 'i', 'o', 'u', 'y' };
            string res = null;
            
            for (int i = 0; i < str.Length; i++)
            {
                int count = 0;
                for (int j = 0; j < vowels.Length; j++) 
                {
                    if (str[i] == vowels[j]) count++;
                }
                if (count==0) res = res + str[i];
            }
            return res;
        }
        public static string DelFiveElem(this string str)
        {
            string res = null;
            int count = 5;
            res = str.Remove(0, count);
            return res;
        }
        public static Arr DelFiveElem(this Arr arr)
        {
            int count = 5;
            Arr res = new Arr((arr.length)-count);

            for (int i = 0; i < res.length; i++)
            {
                res[i] = arr[i + count];
            }
            return res;
        }

    }
}
