﻿using System;
using System.Text;


namespace lab2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("\n= = = = = = = = = = = =\n\tТипы\n= = = = = = = = = = = =\n");

            string str = "heh";
            bool a = true;
            byte b = 6;
            char c = 's';
            decimal d = 15;
            double e = 55.154316855;
            float f = 45.1F;
            int g = 5;
            long h = 4124;
            var str0 = "Строка, строчечка";//неявно типизированная строка
            var mas = new[] { 0, 1, 2, 3, 4, 5 }; //неявно типизированный массив

            Console.WriteLine(a.GetType().Name + " " + a);
            Console.WriteLine(b.GetType().Name + " " + b);
            Console.WriteLine(c.GetType().Name + " " + c);
            Console.WriteLine(d.GetType().Name + " " + d);
            Console.WriteLine(e.GetType().Name + " " + e);
            Console.WriteLine(f.GetType().Name + " " + f);
            Console.WriteLine(g.GetType().Name + " " + g);
            Console.WriteLine(h.GetType().Name + " " + h);

            Console.WriteLine(str.GetType().Name + " " + str);

            int snum = 123;
            Int16 a1 = Convert.ToInt16(snum);
            Int32 a2 = Convert.ToInt32(snum);
            Int64 a3 = Convert.ToInt64(snum);
            Byte a4 = Convert.ToByte(snum);
            Char a5 = Convert.ToChar(snum);
            Decimal a6 = Convert.ToDecimal(snum);
            Double a7 = Convert.ToDouble(snum);

            Int16 c1 = 2;
            Int32 c2 = 5;

            Int64 c3 = c2; // Неявное приведение Int32 к Int64
            Single c4 = c2; // Неявное приведение Int32 к Single
            Int32 c5 = c1;  // Неявное приведение Int16 к Int32
            Double c6 = f;  // Неявное приведение Float к Double
            Double c7 = a3; // Неявное приведение Int64 к Double

            Byte b1 = (Byte)c2; // Явное приведение Int32 к Byte
            Int16 b2 = (Int16)c4; // Явное приведение Single к Int16
            Int32 b3 = (Int32)c1;  // Явное приведение Int16 к Int32
            Double b4 = (Double)f;  // Явное приведение Float к Double
            Double b5 = (Double)a3; // Явное приведение Int64 к Double

            int x = 5;
            Object o = x; // Упаковка x
            byte m = (byte)(int)o; // Распаковка, а затем приведение типа

            var d1 = 2; //неявно типизированная переменная
            var d2 = 3;
            var d3 = d1 + d2;
            //int d3 = 7; 

            int? x1 = null; // Nullable<int> x = 5;
            int? x2 = null;
            Console.Write(x1 == x2); //True

            Console.WriteLine("\n= = = = = = = = = = = =\n\tСтроки\n= = = = = = = = = = = =\n");

            string str1 = "wp", str2 = "gg";
            Console.WriteLine(str1 == str2);
            Console.WriteLine(str1 != str2);
            Console.WriteLine(str1 + str2); //String.Concat(str1,str2);
            string str3 = String.Copy(str1);
            Console.WriteLine(str3);
            string str4 = str3.Substring(1);
            Console.WriteLine(str4);

            string estr = ""; //можно исп методы
            string nstr = null; //можно использовать в операциях объединения и сравнения с другими строками.
            Console.WriteLine(String.IsNullOrEmpty(estr));
            Console.WriteLine(String.IsNullOrEmpty(nstr));
            Console.WriteLine(String.IsNullOrEmpty(str1));

            StringBuilder sb = new StringBuilder("something string", 50);
            sb.Remove(0, 10);
            Console.WriteLine(sb);
            sb.Append(", he");
            Console.WriteLine(sb);
            sb.Insert(0, "Strange ");
            Console.WriteLine(sb);
            Console.WriteLine($"{str1}{str2} - {sb}");


            Console.WriteLine("\n= = = = = = = = = = = =\n\tМассивы\n= = = = = = = = = = = =\n");


            int[][] numbers = new int[3][]; //двумерный массив
            numbers[0] = new int[] { 0, 0, 1 };
            numbers[1] = new int[] { 0, 1, 0 };
            numbers[2] = new int[] { 1, 0, 0 };
            foreach (int[] row in numbers)
            {
                foreach (int number in row)
                {
                    Console.Write($"{number} \t");
                }
                Console.WriteLine();
            }

            int[] aa = { 0, 1, 2, 3, 4, 5 }; //одномерный
            foreach (int gg in aa) Console.Write(gg);
            Console.WriteLine();
            Console.WriteLine(aa.Length);

            Console.WriteLine("Введите значение и позицию элемента, который нужно заменить:");

            int k = Convert.ToInt32(Console.ReadLine()); //значение
            int n = Convert.ToInt32(Console.ReadLine());//позиция

            for (int i = 0; i < aa.Length; i++)
            {
                if (i == n) aa[i - 1] = k;
            }
            foreach (int gg in aa) Console.Write(gg);
            Console.WriteLine();

            int[][] aa2 = { new int[2], new int[3], new int[4] }; //ступеньчатый
            Console.WriteLine("Введите значения матрицы:");
            for (int i = 0; i < aa2.Length; i++)
            {
                for (int j = 0; j < aa2[i].Length; j++)
                { aa2[i][j] = Convert.ToInt32(Console.ReadLine()); }

                Console.WriteLine("||");
            }
            Console.WriteLine();

            foreach (int[] xx2 in aa2)
            {
                foreach (int bb in xx2)
                    Console.Write("\t" + bb);
                Console.WriteLine();
            }

            Console.WriteLine("\n= = = = = = = = = = = =\n\tКортежи\n= = = = = = = = = = = =\n");


            ValueTuple<int, string, char, string, ulong> tuple = (1,"two",'3',"four",1236);
            Console.WriteLine($"{tuple}");
            Console.WriteLine(tuple.Item4);

            var firstTuple = Tuple.Create(9, 3);
            var secondTuple = Tuple.Create(9, 7);

            if (firstTuple == secondTuple)
                Console.WriteLine("Первый кортеж равен второму");
            else
                Console.WriteLine("Первый кортеж не равен второму");

            // распаковка кортежа в переменные.
            var (F1, F2, F3, F4, F5) = tuple;
            Console.WriteLine((F1, F2, F3, F4, F5));

            (int, string, char) CreateCortage(string name)
            {
                int len = name.Length;
                string s = "symbols: " + name;
                char ch = (char)(name[0]);
                return (len, s, ch);
            }
            
            var (one,_, three) = CreateCortage("heeh");
            Console.WriteLine((one, three));

            (int,int,int, char) CreateCortage2(int []a, string name)
            {
                int len = a.Length;
                int min = a.Length;
                int max=0;
                int sum=0;
                for (int i = 0; i < len; i++)
                {
                    if (i < min) min = i;
                    if (i > max) max = i;
                    sum = sum + i;
                }
                char ch = (char)(name[0]);
                return (min,max, sum, ch);
            }
            var (G1, G2, G3, G4) = CreateCortage2(aa, "nice");
            Console.WriteLine((G1, G2, G3, G4));

            void fun1() {
                try
                {
                    checked
                    {
                        int x = int.MaxValue;
                        x++;
                    }
                }
                catch (OverflowException)
                {
                    Console.WriteLine("Произошло переполнение!");
                }
            };
            void fun2() {
                try
                {
                    unchecked // Не вызывает OverflowException
                    {
                        int x = int.MaxValue;
                        x++;
                    }
                }
                catch (OverflowException)
                {
                    Console.WriteLine("Произошло переполнение!");
                }
            };
            fun1();
            fun2();

            Console.ReadKey();

        }
    }
}
