﻿using System;
using System.Collections.Generic;
using System.Text;

namespace lab7
{
    partial class Fiction
    {
        enum Films
        {
            Godfather, Django, Brother, Scarface
        }
    }
    public struct SomeStruct
    {
        public int SomeInt;
        public void SomeMethod()
        {
            Console.WriteLine("Some text");
        }
    }
}
